module.exports = {
  options: {
    host: "localhost",
    user: "root",
    password: "",
    database: "videojuegos24",
  },
};
